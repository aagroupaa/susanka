import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export default function CommentList({ postId, currentUserId }) {
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState('');

  const fetchComments = async () => {
    const { data, error } = await supabase
      .from('comments')
      .select('*, profiles: user_id (email)')
      .eq('post_id', postId)
      .order('created_at');
    if (!error) setComments(data);
  };

  const submitComment = async (e) => {
    e.preventDefault();
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return alert('You must be logged in to comment.');
    if (!commentText.trim()) return;

    const { error } = await supabase.from('comments').insert([
      { post_id: postId, text: commentText, user_id: user.id }
    ]);
    if (!error) {
      setCommentText('');
      fetchComments();
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  return (
    <div className="mt-2 space-y-2">
      {/* Comment form: only if logged in */}
      {currentUserId && (
        <form onSubmit={submitComment} className="flex gap-2">
          <input
            className="flex-grow p-2 border rounded"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder="Add a comment..."
          />
          <button className="bg-secondary text-white px-3 py-1 rounded" type="submit">
            Post
          </button>
        </form>
      )}

      {/* List of comments */}
      {comments.map((comment) => (
        <div key={comment.id} className="text-sm bg-white p-2 border rounded">
          <div className="flex justify-between">
            <div>
              <p>{comment.text}</p>
              {comment.profiles?.email && (
                <p className="text-xs text-gray-500">by {comment.profiles.email}</p>
              )}
            </div>
            {currentUserId === comment.user_id && (
              <div className="flex gap-2 text-xs">
                {/* Optional edit/delete */}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
