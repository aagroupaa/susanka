export default function Footer() {
  return (
    <footer className="text-center text-sm text-gray-500 mt-8 py-4">
      © 2025 Susanka Forum. All rights reserved.
    </footer>
  );
}
